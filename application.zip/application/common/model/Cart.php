<?php
 namespace app\common\model; use think\Model; class Cart extends Model { protected $name = "\171\x62\x6d\160\137\x63\x61\x72\164"; }
