<?php
 namespace app\common\model; class GoodsSupplier extends Base { protected $name = "\171\142\155\x70\137\x67\157\x6f\x64\163\137\163\165\x70\x70\x6c\151\145\x72"; }
