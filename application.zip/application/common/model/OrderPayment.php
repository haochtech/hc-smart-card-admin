<?php
 namespace app\common\model; use think\Model; class OrderPayment extends Model { protected $name = "\x79\x62\x6d\160\x5f\x6f\162\144\x65\162\x5f\160\x61\x79\x6d\x65\x6e\164"; }
