<?php
 namespace app\common\model; class AdminGroup extends Base { protected $name = "\171\142\155\x70\x5f\x61\x64\x6d\151\x6e\137\x72\157\x6c\x65"; }
