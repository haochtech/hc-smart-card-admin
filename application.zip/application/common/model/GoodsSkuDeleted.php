<?php
 namespace app\common\model; use think\Model; class GoodsSkuDeleted extends Base { protected $name = "\171\x62\155\160\x5f\147\157\x6f\x64\163\137\x73\153\x75\x5f\x64\145\154\145\x74\x65\x64"; }
