<?php
 namespace app\common\model; class BusMenu extends Base { protected $name = "\x79\x62\x6d\160\137\142\x75\163\x5f\x6d\145\x6e\165"; }
