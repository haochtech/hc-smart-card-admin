<?php
 namespace app\common\model; class GoodsAttrValue extends Base { protected $name = "\x79\142\155\160\137\x67\157\157\x64\x73\137\141\x74\164\x72\137\x76\141\154\x75\145"; protected $rule = array("\141\164\164\162\137\166\x61\154\165\x65\137\x69\x64" => ''); protected $msg = array("\x61\x74\x74\x72\137\x76\x61\x6c\165\145\x5f\x69\144" => ''); }
