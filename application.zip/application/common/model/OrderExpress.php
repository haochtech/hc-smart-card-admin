<?php
 namespace app\common\model; class OrderExpress extends Base { protected $name = "\x79\142\155\160\x5f\157\x72\144\145\x72\x5f\x65\x78\160\x72\145\x73\163"; }
