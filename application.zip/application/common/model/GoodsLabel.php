<?php
 namespace app\common\model; class GoodsLabel extends Base { protected $name = "\171\142\155\x70\x5f\147\157\157\x64\x73\137\154\141\142\x65\154"; }
