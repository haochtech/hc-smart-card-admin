<?php
 namespace app\common\model; class BargainOrder extends Base { protected $name = "\x79\142\x6d\x70\x5f\x62\141\162\x67\141\x69\156\137\157\x72\x64\145\162"; }
