<?php
 namespace app\common\model; class GoodsAttrModule extends Base { protected $name = "\x79\142\155\x70\137\147\157\x6f\x64\x73\x5f\x61\x74\x74\x72\x5f\155\x6f\144\165\154\x65"; protected $rule = array("\141\x74\x74\162\137\151\144" => ''); protected $msg = array("\141\164\x74\x72\137\x69\144" => ''); }
