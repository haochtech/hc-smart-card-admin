<?php
 namespace app\common\model; class GoodsAttrDel extends Base { protected $name = "\x79\x62\x6d\160\137\147\157\157\x64\x73\137\x61\x74\x74\162\x5f\x64\x65\x6c\x65\x74\145\144"; }
