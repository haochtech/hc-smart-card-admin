<?php
 namespace app\common\model; class UserAddress extends Base { protected $name = "\x79\x62\x6d\x70\137\165\x73\x65\162\x5f\x61\144\144\x72\x65\163\163"; }
