<?php
 namespace app\common\model; class GoodsSku extends Base { protected $name = "\171\x62\155\x70\x5f\x67\x6f\157\x64\x73\x5f\163\x6b\165"; protected $rule = array("\x73\x6b\x75\137\151\144" => ''); protected $msg = array("\x73\x6b\x75\x5f\x69\x64" => ''); }
