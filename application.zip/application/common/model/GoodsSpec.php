<?php
 namespace app\common\model; use think\Model; class GoodsSpec extends Base { protected $name = "\171\x62\x6d\160\x5f\x67\157\x6f\x64\163\137\163\x70\145\x63"; protected $rule = array("\163\160\x65\143\x5f\151\x64" => ''); protected $msg = array("\x73\160\x65\143\137\151\144" => ''); }
