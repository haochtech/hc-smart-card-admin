<?php
 namespace app\common\model; class AdvertPosition extends Base { protected $name = "\171\142\x6d\x70\137\141\x64\x76\145\162\x74\137\160\x6f\x73\x69\164\x69\157\156"; }
