<?php
 namespace app\common\model; class ArticleClass extends Base { protected $name = "\171\x62\x6d\160\137\x61\162\164\151\143\154\145\x5f\x63\154\x61\163\x73"; }
