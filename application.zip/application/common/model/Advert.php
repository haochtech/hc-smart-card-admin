<?php
 namespace app\common\model; class Advert extends Base { protected $name = "\171\142\x6d\x70\137\141\x64\x76\145\x72\x74"; }
