<?php
 namespace app\common\model; class GoodsCate extends Base { protected $name = "\171\142\x6d\x70\x5f\x67\157\x6f\x64\163\x5f\143\141\x74\x65"; protected $rule = array("\143\x61\x74\145\137\151\x64" => ''); protected $msg = array("\143\141\x74\x65\137\151\x64" => ''); }
