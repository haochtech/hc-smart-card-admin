<?php
 namespace app\common\model; class Addons extends Base { protected $name = "\x79\142\155\160\137\141\144\x64\x6f\x6e\163"; }
