<?php
 namespace app\common\model; class About extends Base { protected $name = "\171\142\x6d\x70\x5f\142\x75\x73\x69\x6e\145\163\x73\137\x61\x62\x6f\165\x74"; }
