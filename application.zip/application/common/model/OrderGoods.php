<?php
 namespace app\common\model; class OrderGoods extends Base { protected $name = "\171\142\155\160\137\x6f\x72\x64\145\x72\137\147\157\x6f\144\163"; }
