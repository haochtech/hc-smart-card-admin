<?php
 namespace app\common\model; class Business extends Base { protected $name = "\171\x62\x6d\160\x5f\x62\165\x73\151\156\x65\163\163"; }
