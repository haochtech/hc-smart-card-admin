<?php
 namespace app\common\model; class BargainVerification extends Base { protected $name = "\x79\142\x6d\160\137\x62\141\162\147\x61\151\156\137\x76\x65\162\151\146\151\x63\x61\x74\151\157\x6e"; }
