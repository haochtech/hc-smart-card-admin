<?php
 namespace app\common\model; class Bargain extends Base { protected $name = "\x79\x62\155\160\137\x62\x61\x72\147\x61\x69\x6e"; }
