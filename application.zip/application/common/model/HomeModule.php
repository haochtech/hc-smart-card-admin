<?php
 namespace app\common\model; class HomeModule extends Base { protected $name = "\x79\142\155\160\x5f\155\157\x64\165\x6c\x65"; }
