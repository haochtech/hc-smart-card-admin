<?php
 namespace app\common\model; class ExpressShipping extends Base { protected $name = "\171\142\x6d\160\137\x65\x78\160\162\145\163\x73\137\x73\x68\x69\160\160\151\x6e\x67"; }
