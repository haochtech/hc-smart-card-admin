<?php
 namespace app\common\model; use think\Model; class Module extends Base { protected $name = "\171\142\x6d\160\x5f\141\144\155\151\156\x5f\155\157\x64\165\x6c\145"; }
