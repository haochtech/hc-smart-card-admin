<?php
 namespace app\common\model; class GoodsAttr extends Base { protected $name = "\x79\142\155\160\137\147\x6f\x6f\144\x73\137\x61\x74\x74\x72"; }
