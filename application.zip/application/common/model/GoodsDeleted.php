<?php
 namespace app\common\model; class GoodsDeleted extends Base { protected $name = "\171\x62\x6d\160\137\x67\x6f\157\144\x73\137\x64\145\154\x65\164\x65\x64"; }
