<?php
 namespace app\common\model; class BargainHelp extends Base { protected $name = "\x79\x62\155\160\137\142\141\x72\x67\x61\x69\156\x5f\x68\x65\x6c\160"; }
