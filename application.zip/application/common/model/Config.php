<?php
 namespace app\common\model; class Config extends Base { protected $name = "\171\x62\x6d\x70\137\x63\x6f\156\146\x69\147"; }
