<?php
 namespace app\common\model; use think\Model; class GoodsSpecValue extends Base { protected $name = "\x79\x62\155\160\x5f\147\x6f\x6f\144\163\137\x73\x70\145\143\x5f\x76\141\x6c\165\145"; protected $rule = array("\163\160\x65\x63\137\166\141\x6c\x75\145\137\x69\144" => ''); protected $msg = array("\163\160\x65\x63\137\166\x61\154\x75\145\x5f\151\x64" => ''); }
