<?php
 namespace app\common\model; class ExpressCompany extends Base { protected $name = "\171\142\x6d\x70\137\x65\x78\x70\x72\145\x73\x73\x5f\x63\157\x6d\x70\x61\156\171"; protected $rule = array("\x63\157\137\151\144" => ''); protected $msg = array("\x63\x6f\x5f\x69\x64" => ''); }
