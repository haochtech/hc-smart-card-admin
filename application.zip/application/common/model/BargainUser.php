<?php
 namespace app\common\model; class BargainUser extends Base { protected $name = "\x79\142\155\x70\137\x62\x61\162\147\141\151\x6e\x5f\165\x73\x65\162"; }
