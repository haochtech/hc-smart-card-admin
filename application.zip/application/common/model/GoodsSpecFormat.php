<?php
 namespace app\common\model; class GoodsSpecFormat extends Base { protected $name = "\171\142\155\160\137\147\157\x6f\x64\x73\137\163\x70\x65\x63\137\x66\157\x72\x6d\x61\x74"; }
