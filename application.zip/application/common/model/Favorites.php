<?php
 namespace app\common\model; class Favorites extends Base { protected $name = "\171\142\x6d\x70\137\x66\x61\166\157\162\x69\164\x65\163"; }
