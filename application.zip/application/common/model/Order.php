<?php
 namespace app\common\model; class Order extends Base { protected $name = "\x79\x62\x6d\160\x5f\x6f\162\x64\145\162"; }
