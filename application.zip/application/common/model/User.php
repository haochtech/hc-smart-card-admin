<?php
 namespace app\common\model; class User extends Base { protected $name = "\171\x62\x6d\x70\x5f\x75\163\x65\162"; }
