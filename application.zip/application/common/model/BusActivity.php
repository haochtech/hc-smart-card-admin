<?php
 namespace app\common\model; class BusActivity extends Base { protected $name = "\171\x62\x6d\160\x5f\142\x75\163\x69\156\x65\x73\x73\137\x61\x63\164\x69\166\x69\164\x79"; }
