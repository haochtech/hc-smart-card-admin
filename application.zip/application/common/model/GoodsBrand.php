<?php
 namespace app\common\model; class GoodsBrand extends Base { protected $name = "\x79\142\x6d\160\x5f\147\157\157\144\163\137\x62\162\x61\156\144"; }
