<?php
 namespace app\common\model; class Admin extends Base { protected $name = "\x79\x62\155\160\x5f\141\x64\x6d\x69\156"; }
