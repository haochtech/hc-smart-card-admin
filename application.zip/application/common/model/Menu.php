<?php
 namespace app\common\model; class Menu extends Base { protected $name = "\x79\142\155\160\x5f\164\155\x70\x6c\137\x6d\x65\x6e\165"; }
