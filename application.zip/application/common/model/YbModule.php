<?php
 namespace app\common\model; class YbModule extends Base { protected $name = "\171\142\x6d\x70\x5f\155\157\144\x75\154\x65"; }
