<?php
 namespace app\common\model; class ImagesGroup extends Base { protected $name = "\x79\142\x6d\x70\137\x69\155\x61\147\145\163\137\x67\x72\157\x75\x70"; protected $rule = array("\x67\162\x6f\165\x70\x5f\151\144" => ''); protected $msg = array("\x67\x72\157\165\x70\x5f\x69\144" => ''); }
